# Ziyaretçi Yönetim Sistemi

## Proje Amacı
Güvenlik kulübesi, fabrika, site, şantiye gibi alanlarda kullanılmak üzere tasarlanmış offline ziyaretçi, personel ve duyuru yönetim sistemi.

## Teknik Özellikler
- **Frontend**: Vanilla HTML/CSS/JavaScript (kurulum gerektirmez)
- **Veri Saklama**: LocalStorage (tarayıcı hafızası)
- **Excel İşlemleri**: SheetJS kütüphanesi (CDN üzerinden)
- **Tema**: Koyu/Açık tema, altın-siyah renk paleti
- **Saat Dilimi**: Türkiye saati (UTC+3)

## Dosya Yapısı
```
/
├── index.html      # Ana arayüz
├── style.css       # Tüm CSS stilleri
├── app.js          # Uygulama mantığı
└── replit.md       # Bu dosya
```

## Özellikler

### Dashboard
- Bugünkü ziyaretçi sayısı
- Toplam ziyaretçi
- İçerideki aktif ziyaretçiler
- Hızlı işlem butonları
- Son ziyaretçiler tablosu

### Ziyaretçi Yönetimi
- Ziyaretçi kayıt formu (Ad, Firma, Plaka, Geliş Nedeni)
- Otomatik tarih/saat
- Hızlı kayıt (otomatik öneri)
- Arama ve filtreleme
- Çıkış kaydı

### Personel Yönetimi
- Personel ekleme/silme
- Kayıt yapan personel dropdown'ı

### Duyuru Paneli
- Kayan yazı duyuruları
- Sabit duyurular
- Tarih bazlı gösterim

### Excel İşlemleri
- Tüm verileri Excel'e indir
- Excel'den içe aktar
- Bireysel tablo indirme

## Veri Yapısı (LocalStorage)

### visitors (Ziyaretçiler)
```json
{
  "id": "unique_id",
  "date": "16.12.2024",
  "entryTime": "14:30",
  "exitTime": "16:00",
  "name": "AD SOYAD",
  "company": "Firma Adı",
  "plate": "34ABC123",
  "reason": "Toplantı",
  "registeredBy": "ERHAN YAMAN",
  "status": "İçeride" | "Çıkış Yaptı"
}
```

### personnel (Personel)
```json
{
  "id": 1,
  "name": "AD SOYAD",
  "position": "Güvenlik",
  "phone": "05xx xxx xx xx",
  "plate": "34ABC123",
  "type": "Şirket" | "Taşeron" | "Güvenlik"
}
```

### announcements (Duyurular)
```json
{
  "id": "unique_id",
  "title": "Başlık",
  "content": "İçerik",
  "type": "Kayan" | "Sabit",
  "startDate": "2024-12-16",
  "endDate": "2024-12-31",
  "page": "all" | "dashboard" | "ziyaretci"
}
```

## Kullanım
1. index.html dosyasını tarayıcıda açın
2. Personel ekleyin (ilk kullanımda)
3. Ziyaretçi kayıtları oluşturun
4. İstediğiniz zaman Excel'e aktarın

## Notlar
- Veriler tarayıcı LocalStorage'da saklanır
- Tarayıcı önbelleği temizlenirse veriler silinir
- Düzenli olarak Excel'e yedek alın
