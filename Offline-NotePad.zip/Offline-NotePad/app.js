// Ziyaretçi Yönetim Sistemi - Ana Uygulama
// Tüm veriler LocalStorage'da saklanır, Excel'e aktarılabilir

// ===================== VERI YONETIMI =====================
const DB = {
    get: function(key) {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    },
    set: function(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    },
    init: function() {
        if (!this.get('visitors')) this.set('visitors', []);
        if (!this.get('personnel')) this.set('personnel', [
            { id: 1, name: 'ERHAN YAMAN', position: 'Güvenlik', phone: '', plate: '', type: 'Güvenlik' }
        ]);
        if (!this.get('announcements')) this.set('announcements', []);
        if (!this.get('settings')) this.set('settings', {
            theme: 'dark',
            defaultRegisteredBy: ''
        });
    }
};

// Uygulama baslarken veritabanini baslat
DB.init();

// ===================== YARDIMCI FONKSIYONLAR =====================
function getTurkeyTime() {
    const now = new Date();
    const turkeyOffset = 3 * 60;
    const localOffset = now.getTimezoneOffset();
    const turkeyTime = new Date(now.getTime() + (turkeyOffset + localOffset) * 60000);
    return turkeyTime;
}

function formatDate(date) {
    const d = date || getTurkeyTime();
    return d.toLocaleDateString('tr-TR');
}

function formatTime(date) {
    const d = date || getTurkeyTime();
    return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}

function formatDateTime(date) {
    const d = date || getTurkeyTime();
    return d.toLocaleString('tr-TR');
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    toast.innerHTML = `${icons[type]} ${message}`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// ===================== SAYFA YONETIMI =====================
function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const pages = document.querySelectorAll('.page');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const closeSidebar = document.getElementById('closeSidebar');

    function showPage(pageId) {
        pages.forEach(page => page.classList.remove('active'));
        navLinks.forEach(link => link.classList.remove('active'));
        
        const targetPage = document.getElementById(`page-${pageId}`);
        const targetLink = document.querySelector(`[data-page="${pageId}"]`);
        
        if (targetPage) targetPage.classList.add('active');
        if (targetLink) targetLink.classList.add('active');
        
        closeSidebarMenu();
        
        // Sayfa degistiginde verileri guncelle
        if (pageId === 'dashboard') updateDashboard();
        if (pageId === 'ziyaretciler') renderVisitorsTable();
        if (pageId === 'personel') renderPersonnelTable();
        if (pageId === 'duyuru') renderAnnouncements();
    }

    function openSidebarMenu() {
        sidebar.classList.add('active');
        overlay.classList.add('active');
    }

    function closeSidebarMenu() {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    }

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = link.dataset.page;
            showPage(pageId);
        });
    });

    // Hizli islem butonlari
    document.querySelectorAll('[data-page]').forEach(btn => {
        if (!btn.classList.contains('nav-link')) {
            btn.addEventListener('click', () => {
                const pageId = btn.dataset.page;
                showPage(pageId);
            });
        }
    });

    hamburgerBtn.addEventListener('click', openSidebarMenu);
    closeSidebar.addEventListener('click', closeSidebarMenu);
    overlay.addEventListener('click', closeSidebarMenu);
}

// ===================== TEMA YONETIMI =====================
function initTheme() {
    const settings = DB.get('settings');
    const body = document.body;
    const themeToggle = document.getElementById('themeToggle');
    const themeOptions = document.querySelectorAll('.theme-option');

    function setTheme(theme) {
        body.classList.remove('dark-theme', 'light-theme');
        body.classList.add(`${theme}-theme`);
        themeToggle.querySelector('.theme-icon').textContent = theme === 'dark' ? '🌙' : '☀️';
        
        themeOptions.forEach(opt => {
            opt.classList.toggle('active', opt.dataset.theme === theme);
        });
        
        const s = DB.get('settings');
        s.theme = theme;
        DB.set('settings', s);
    }

    setTheme(settings.theme || 'dark');

    themeToggle.addEventListener('click', () => {
        const currentTheme = body.classList.contains('dark-theme') ? 'dark' : 'light';
        setTheme(currentTheme === 'dark' ? 'light' : 'dark');
    });

    themeOptions.forEach(opt => {
        opt.addEventListener('click', () => setTheme(opt.dataset.theme));
    });
}

// ===================== TARIH/SAAT GUNCELLEME =====================
function initDateTime() {
    const datetimeEl = document.getElementById('datetime');
    const visitDateEl = document.getElementById('visitDate');
    const visitTimeEl = document.getElementById('visitTime');

    function updateDateTime() {
        const now = getTurkeyTime();
        datetimeEl.textContent = formatDateTime(now);
        if (visitDateEl) visitDateEl.value = formatDate(now);
        if (visitTimeEl) visitTimeEl.value = formatTime(now);
    }

    updateDateTime();
    setInterval(updateDateTime, 1000);
}

// ===================== DASHBOARD =====================
function updateDashboard() {
    const visitors = DB.get('visitors') || [];
    const personnel = DB.get('personnel') || [];
    const today = formatDate();

    // Istatistikler
    const todayVisitors = visitors.filter(v => v.date === today);
    const activeVisitors = visitors.filter(v => v.status === 'İçeride');
    
    document.getElementById('todayVisitors').textContent = todayVisitors.length;
    document.getElementById('totalVisitors').textContent = visitors.length;
    document.getElementById('activeVisitors').textContent = activeVisitors.length;
    document.getElementById('totalPersonnel').textContent = personnel.length;

    // Son ziyaretciler tablosu
    const recentTable = document.getElementById('recentVisitorsTable');
    const recent = visitors.slice(-10).reverse();
    
    recentTable.innerHTML = recent.length ? recent.map(v => `
        <tr>
            <td>${v.date}</td>
            <td>${v.entryTime}</td>
            <td>${v.name}</td>
            <td>${v.company || '-'}</td>
            <td>${v.plate || '-'}</td>
            <td><span class="status-badge ${v.status === 'İçeride' ? 'status-inside' : 'status-left'}">${v.status}</span></td>
        </tr>
    `).join('') : '<tr><td colspan="6" style="text-align:center;padding:30px;">Henüz ziyaretçi kaydı yok</td></tr>';
}

// ===================== PERSONEL DROPDOWN GUNCELLEME =====================
function updatePersonnelDropdowns() {
    const personnel = DB.get('personnel') || [];
    const dropdowns = [
        document.getElementById('registeredBy'),
        document.getElementById('filterRegisteredBy'),
        document.getElementById('defaultRegisteredBy')
    ];

    dropdowns.forEach(dropdown => {
        if (!dropdown) return;
        const currentValue = dropdown.value;
        const isFilter = dropdown.id === 'filterRegisteredBy';
        
        dropdown.innerHTML = isFilter ? '<option value="">Tüm Personel</option>' : '<option value="">Seçiniz...</option>';
        
        personnel.forEach(p => {
            const option = document.createElement('option');
            option.value = p.name;
            option.textContent = p.name;
            dropdown.appendChild(option);
        });
        
        if (currentValue) dropdown.value = currentValue;
    });

    // Varsayilan kayit yapan
    const settings = DB.get('settings');
    if (settings.defaultRegisteredBy) {
        const registeredBy = document.getElementById('registeredBy');
        if (registeredBy && !registeredBy.value) {
            registeredBy.value = settings.defaultRegisteredBy;
        }
    }
}

// ===================== ZIYARETCI KAYIT =====================
function initVisitorForm() {
    const form = document.getElementById('visitorForm');
    const nameInput = document.getElementById('visitorName');
    const companyInput = document.getElementById('visitorCompany');
    const plateInput = document.getElementById('visitorPlate');

    // Otomatik tamamlama
    function setupAutocomplete(input, suggestionDiv, field) {
        input.addEventListener('input', () => {
            const value = input.value.toLowerCase().trim();
            if (value.length < 2) {
                suggestionDiv.classList.remove('active');
                return;
            }

            const visitors = DB.get('visitors') || [];
            const unique = [...new Set(visitors.map(v => v[field]).filter(Boolean))];
            const matches = unique.filter(item => item.toLowerCase().includes(value)).slice(0, 5);

            if (matches.length) {
                suggestionDiv.innerHTML = matches.map(m => 
                    `<div class="suggestion-item" data-value="${m}">${m}</div>`
                ).join('');
                suggestionDiv.classList.add('active');
            } else {
                suggestionDiv.classList.remove('active');
            }
        });

        suggestionDiv.addEventListener('click', (e) => {
            if (e.target.classList.contains('suggestion-item')) {
                const value = e.target.dataset.value;
                input.value = value;
                suggestionDiv.classList.remove('active');

                // Otomatik doldurma
                const visitors = DB.get('visitors') || [];
                const match = visitors.find(v => v[field] === value);
                if (match) {
                    if (field === 'name') {
                        companyInput.value = match.company || '';
                        plateInput.value = match.plate || '';
                    }
                }
            }
        });

        input.addEventListener('blur', () => {
            setTimeout(() => suggestionDiv.classList.remove('active'), 200);
        });
    }

    setupAutocomplete(nameInput, document.getElementById('nameSuggestions'), 'name');
    setupAutocomplete(companyInput, document.getElementById('companySuggestions'), 'company');
    setupAutocomplete(plateInput, document.getElementById('plateSuggestions'), 'plate');

    // Form gonderimi
    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const visitor = {
            id: generateId(),
            date: document.getElementById('visitDate').value,
            entryTime: document.getElementById('visitTime').value,
            exitTime: '',
            name: nameInput.value.trim().toUpperCase(),
            company: companyInput.value.trim(),
            plate: plateInput.value.trim().toUpperCase(),
            reason: document.getElementById('visitReason').value,
            registeredBy: document.getElementById('registeredBy').value,
            status: 'İçeride'
        };

        const visitors = DB.get('visitors') || [];
        visitors.push(visitor);
        DB.set('visitors', visitors);

        showToast('Ziyaretçi kaydı başarıyla oluşturuldu!');
        form.reset();
        updateDashboard();
        initDateTime();
    });
}

// ===================== ZIYARETCI LISTESI =====================
let currentPage = 1;
const itemsPerPage = 20;

function renderVisitorsTable() {
    const visitors = DB.get('visitors') || [];
    const tbody = document.getElementById('visitorsTable');
    const searchValue = document.getElementById('searchVisitor').value.toLowerCase();
    const dateFilter = document.getElementById('filterDate').value;
    const statusFilter = document.getElementById('filterStatus').value;
    const personnelFilter = document.getElementById('filterRegisteredBy').value;

    // Filtreleme
    let filtered = visitors.filter(v => {
        const matchSearch = !searchValue || 
            v.name.toLowerCase().includes(searchValue) ||
            (v.company && v.company.toLowerCase().includes(searchValue)) ||
            (v.plate && v.plate.toLowerCase().includes(searchValue));
        
        const matchDate = !dateFilter || v.date === new Date(dateFilter).toLocaleDateString('tr-TR');
        const matchStatus = !statusFilter || v.status === statusFilter;
        const matchPersonnel = !personnelFilter || v.registeredBy === personnelFilter;

        return matchSearch && matchDate && matchStatus && matchPersonnel;
    });

    // Sirala (yeniden eskiye)
    filtered = filtered.reverse();

    // Sayfalama
    const totalPages = Math.ceil(filtered.length / itemsPerPage);
    const start = (currentPage - 1) * itemsPerPage;
    const paged = filtered.slice(start, start + itemsPerPage);

    tbody.innerHTML = paged.length ? paged.map(v => `
        <tr>
            <td>${v.date}</td>
            <td>${v.entryTime}</td>
            <td>${v.exitTime || '-'}</td>
            <td>${v.name}</td>
            <td>${v.company || '-'}</td>
            <td>${v.plate || '-'}</td>
            <td>${v.reason}</td>
            <td>${v.registeredBy}</td>
            <td><span class="status-badge ${v.status === 'İçeride' ? 'status-inside' : 'status-left'}">${v.status}</span></td>
            <td>
                ${v.status === 'İçeride' ? 
                    `<button class="btn btn-small btn-accent" onclick="markExit('${v.id}')">🚪 Çıkış</button>` : 
                    ''
                }
                <button class="btn btn-small btn-danger" onclick="deleteVisitor('${v.id}')">🗑️</button>
            </td>
        </tr>
    `).join('') : '<tr><td colspan="10" style="text-align:center;padding:30px;">Kayıt bulunamadı</td></tr>';

    // Sayfalama butonlari
    renderPagination(totalPages);
}

function renderPagination(totalPages) {
    const pagination = document.getElementById('visitorsPagination');
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }

    let html = '';
    for (let i = 1; i <= totalPages; i++) {
        html += `<button class="${i === currentPage ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
    }
    pagination.innerHTML = html;
}

function goToPage(page) {
    currentPage = page;
    renderVisitorsTable();
}

function markExit(id) {
    const visitors = DB.get('visitors') || [];
    const visitor = visitors.find(v => v.id === id);
    if (visitor) {
        visitor.status = 'Çıkış Yaptı';
        visitor.exitTime = formatTime();
        DB.set('visitors', visitors);
        renderVisitorsTable();
        updateDashboard();
        showToast(`${visitor.name} çıkış kaydı yapıldı`);
    }
}

function deleteVisitor(id) {
    if (!confirm('Bu ziyaretçi kaydını silmek istediğinizden emin misiniz?')) return;
    
    let visitors = DB.get('visitors') || [];
    visitors = visitors.filter(v => v.id !== id);
    DB.set('visitors', visitors);
    renderVisitorsTable();
    updateDashboard();
    showToast('Kayıt silindi', 'warning');
}

function initVisitorFilters() {
    const searchInput = document.getElementById('searchVisitor');
    const dateFilter = document.getElementById('filterDate');
    const statusFilter = document.getElementById('filterStatus');
    const personnelFilter = document.getElementById('filterRegisteredBy');
    const clearBtn = document.getElementById('clearFilters');

    [searchInput, dateFilter, statusFilter, personnelFilter].forEach(el => {
        el.addEventListener('change', () => {
            currentPage = 1;
            renderVisitorsTable();
        });
    });

    searchInput.addEventListener('input', () => {
        currentPage = 1;
        renderVisitorsTable();
    });

    clearBtn.addEventListener('click', () => {
        searchInput.value = '';
        dateFilter.value = '';
        statusFilter.value = '';
        personnelFilter.value = '';
        currentPage = 1;
        renderVisitorsTable();
    });
}

// ===================== PERSONEL YONETIMI =====================
function renderPersonnelTable() {
    const personnel = DB.get('personnel') || [];
    const tbody = document.getElementById('personnelTable');

    tbody.innerHTML = personnel.length ? personnel.map(p => `
        <tr>
            <td>${p.name}</td>
            <td>${p.position || '-'}</td>
            <td>${p.phone || '-'}</td>
            <td>
                <button class="btn btn-small btn-danger" onclick="deletePersonnel(${p.id})">🗑️</button>
            </td>
        </tr>
    `).join('') : '<tr><td colspan="4" style="text-align:center;padding:20px;">Henüz personel kaydı yok</td></tr>';
}

function initPersonnelForm() {
    const form = document.getElementById('personnelForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const personnel = DB.get('personnel') || [];
        const newId = personnel.length ? Math.max(...personnel.map(p => p.id)) + 1 : 1;

        const person = {
            id: newId,
            name: document.getElementById('personnelName').value.trim().toUpperCase(),
            position: document.getElementById('personnelPosition').value.trim(),
            phone: document.getElementById('personnelPhone').value.trim(),
            plate: document.getElementById('personnelPlate').value.trim().toUpperCase(),
            type: document.getElementById('personnelType').value
        };

        personnel.push(person);
        DB.set('personnel', personnel);

        showToast('Personel başarıyla eklendi!');
        form.reset();
        renderPersonnelTable();
        updatePersonnelDropdowns();
        updateDashboard();
    });
}

function deletePersonnel(id) {
    if (!confirm('Bu personeli silmek istediğinizden emin misiniz?')) return;
    
    let personnel = DB.get('personnel') || [];
    personnel = personnel.filter(p => p.id !== id);
    DB.set('personnel', personnel);
    renderPersonnelTable();
    updatePersonnelDropdowns();
    updateDashboard();
    showToast('Personel silindi', 'warning');
}

// ===================== DUYURU YONETIMI =====================
function renderAnnouncements() {
    const announcements = DB.get('announcements') || [];
    const list = document.getElementById('announcementsList');
    const today = new Date().toISOString().split('T')[0];

    // Aktif duyurulari filtrele
    const active = announcements.filter(a => {
        if (a.startDate && a.startDate > today) return false;
        if (a.endDate && a.endDate < today) return false;
        return true;
    });

    list.innerHTML = active.length ? active.map(a => `
        <div class="announcement-item">
            <h4>${a.title}</h4>
            <p>${a.content}</p>
            <div class="announcement-meta">
                <span>📌 ${a.type} | 📄 ${a.page === 'all' ? 'Tüm Sayfalar' : a.page}</span>
                <button class="btn btn-small btn-danger" onclick="deleteAnnouncement('${a.id}')">🗑️</button>
            </div>
        </div>
    `).join('') : '<p style="text-align:center;opacity:0.7;">Aktif duyuru yok</p>';

    // Kayan yaziyi guncelle
    updateMarquee();
}

function updateMarquee() {
    const announcements = DB.get('announcements') || [];
    const marquee = document.getElementById('marqueeContent');
    const container = document.getElementById('marqueeContainer');
    const today = new Date().toISOString().split('T')[0];

    const scrolling = announcements.filter(a => {
        if (a.type !== 'Kayan') return false;
        if (a.startDate && a.startDate > today) return false;
        if (a.endDate && a.endDate < today) return false;
        return true;
    });

    if (scrolling.length) {
        marquee.textContent = scrolling.map(a => `📢 ${a.title}: ${a.content}`).join('   |   ');
        container.style.display = 'block';
    } else {
        container.style.display = 'none';
    }
}

function initAnnouncementForm() {
    const form = document.getElementById('announcementForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const announcement = {
            id: generateId(),
            title: document.getElementById('announcementTitle').value.trim(),
            content: document.getElementById('announcementContent').value.trim(),
            type: document.getElementById('announcementType').value,
            startDate: document.getElementById('announcementStart').value,
            endDate: document.getElementById('announcementEnd').value,
            page: document.getElementById('announcementPage').value
        };

        const announcements = DB.get('announcements') || [];
        announcements.push(announcement);
        DB.set('announcements', announcements);

        showToast('Duyuru başarıyla eklendi!');
        form.reset();
        renderAnnouncements();
    });
}

function deleteAnnouncement(id) {
    if (!confirm('Bu duyuruyu silmek istediğinizden emin misiniz?')) return;
    
    let announcements = DB.get('announcements') || [];
    announcements = announcements.filter(a => a.id !== id);
    DB.set('announcements', announcements);
    renderAnnouncements();
    showToast('Duyuru silindi', 'warning');
}

// ===================== HIZLI CIKIS MODAL =====================
function initQuickExitModal() {
    const modal = document.getElementById('quickExitModal');
    const openBtn = document.getElementById('quickExitBtn');
    const closeBtn = document.getElementById('closeQuickExitModal');
    const list = document.getElementById('activeVisitorsList');

    openBtn.addEventListener('click', () => {
        const visitors = DB.get('visitors') || [];
        const active = visitors.filter(v => v.status === 'İçeride');

        list.innerHTML = active.length ? active.map(v => `
            <div class="active-visitor-item">
                <div class="active-visitor-info">
                    <span class="active-visitor-name">${v.name}</span>
                    <span class="active-visitor-details">${v.company || '-'} | ${v.plate || '-'} | Giriş: ${v.entryTime}</span>
                </div>
                <button class="btn btn-small btn-accent" onclick="markExitFromModal('${v.id}')">🚪 Çıkış</button>
            </div>
        `).join('') : '<p style="text-align:center;padding:20px;opacity:0.7;">İçeride ziyaretçi yok</p>';

        modal.classList.add('active');
    });

    closeBtn.addEventListener('click', () => modal.classList.remove('active'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
    });
}

function markExitFromModal(id) {
    markExit(id);
    document.getElementById('quickExitModal').classList.remove('active');
}

// ===================== EXCEL ISLEMLERI =====================
function exportToExcel(data, filename, headers) {
    const ws = XLSX.utils.json_to_sheet(data, { header: headers });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sayfa1');
    XLSX.writeFile(wb, filename);
}

function initExcelExport() {
    // Tum verileri indir
    document.getElementById('exportAllBtn').addEventListener('click', () => {
        const visitors = DB.get('visitors') || [];
        const personnel = DB.get('personnel') || [];
        const announcements = DB.get('announcements') || [];

        const wb = XLSX.utils.book_new();

        // Ziyaretciler sayfasi
        if (visitors.length) {
            const visitorData = visitors.map(v => ({
                'Tarih': v.date,
                'Giriş Saati': v.entryTime,
                'Çıkış Saati': v.exitTime || '',
                'Ad Soyad': v.name,
                'Firma': v.company || '',
                'Plaka': v.plate || '',
                'Geliş Nedeni': v.reason,
                'Kayıt Yapan': v.registeredBy,
                'Durum': v.status
            }));
            const ws1 = XLSX.utils.json_to_sheet(visitorData);
            XLSX.utils.book_append_sheet(wb, ws1, 'Ziyaretçiler');
        }

        // Personel sayfasi
        if (personnel.length) {
            const personnelData = personnel.map(p => ({
                'ID': p.id,
                'Ad Soyad': p.name,
                'Pozisyon': p.position || '',
                'Telefon': p.phone || '',
                'Plaka': p.plate || '',
                'Tür': p.type || ''
            }));
            const ws2 = XLSX.utils.json_to_sheet(personnelData);
            XLSX.utils.book_append_sheet(wb, ws2, 'Personel');
        }

        // Duyurular sayfasi
        if (announcements.length) {
            const announcementData = announcements.map(a => ({
                'ID': a.id,
                'Başlık': a.title,
                'İçerik': a.content,
                'Tür': a.type,
                'Başlangıç': a.startDate || '',
                'Bitiş': a.endDate || '',
                'Sayfa': a.page
            }));
            const ws3 = XLSX.utils.json_to_sheet(announcementData);
            XLSX.utils.book_append_sheet(wb, ws3, 'Duyurular');
        }

        const date = formatDate().replace(/\./g, '-');
        XLSX.writeFile(wb, `ZiyaretciYonetim_${date}.xlsx`);
        showToast('Tüm veriler Excel dosyasına aktarıldı!');
    });

    // Bireysel indirmeler
    document.getElementById('exportVisitors').addEventListener('click', () => {
        const visitors = DB.get('visitors') || [];
        if (!visitors.length) {
            showToast('İndirilecek ziyaretçi kaydı yok', 'warning');
            return;
        }
        const data = visitors.map(v => ({
            'Tarih': v.date,
            'Giriş Saati': v.entryTime,
            'Çıkış Saati': v.exitTime || '',
            'Ad Soyad': v.name,
            'Firma': v.company || '',
            'Plaka': v.plate || '',
            'Geliş Nedeni': v.reason,
            'Kayıt Yapan': v.registeredBy,
            'Durum': v.status
        }));
        exportToExcel(data, `Ziyaretciler_${formatDate().replace(/\./g, '-')}.xlsx`);
        showToast('Ziyaretçiler Excel dosyasına aktarıldı!');
    });

    document.getElementById('exportPersonnel').addEventListener('click', () => {
        const personnel = DB.get('personnel') || [];
        if (!personnel.length) {
            showToast('İndirilecek personel kaydı yok', 'warning');
            return;
        }
        const data = personnel.map(p => ({
            'ID': p.id,
            'Ad Soyad': p.name,
            'Pozisyon': p.position || '',
            'Telefon': p.phone || '',
            'Plaka': p.plate || '',
            'Tür': p.type || ''
        }));
        exportToExcel(data, `Personel_${formatDate().replace(/\./g, '-')}.xlsx`);
        showToast('Personel Excel dosyasına aktarıldı!');
    });

    document.getElementById('exportAnnouncements').addEventListener('click', () => {
        const announcements = DB.get('announcements') || [];
        if (!announcements.length) {
            showToast('İndirilecek duyuru yok', 'warning');
            return;
        }
        const data = announcements.map(a => ({
            'ID': a.id,
            'Başlık': a.title,
            'İçerik': a.content,
            'Tür': a.type,
            'Başlangıç': a.startDate || '',
            'Bitiş': a.endDate || '',
            'Sayfa': a.page
        }));
        exportToExcel(data, `Duyurular_${formatDate().replace(/\./g, '-')}.xlsx`);
        showToast('Duyurular Excel dosyasına aktarıldı!');
    });
}

function initExcelImport() {
    const importBtn = document.getElementById('importBtn');
    const importFile = document.getElementById('importFile');

    importBtn.addEventListener('click', () => importFile.click());

    importFile.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const data = new Uint8Array(event.target.result);
                const workbook = XLSX.read(data, { type: 'array' });

                // Ziyaretciler sayfasi
                if (workbook.SheetNames.includes('Ziyaretçiler')) {
                    const sheet = workbook.Sheets['Ziyaretçiler'];
                    const json = XLSX.utils.sheet_to_json(sheet);
                    const visitors = json.map(row => ({
                        id: generateId(),
                        date: row['Tarih'] || '',
                        entryTime: row['Giriş Saati'] || '',
                        exitTime: row['Çıkış Saati'] || '',
                        name: row['Ad Soyad'] || '',
                        company: row['Firma'] || '',
                        plate: row['Plaka'] || '',
                        reason: row['Geliş Nedeni'] || '',
                        registeredBy: row['Kayıt Yapan'] || '',
                        status: row['Durum'] || 'Çıkış Yaptı'
                    }));
                    const existing = DB.get('visitors') || [];
                    DB.set('visitors', [...existing, ...visitors]);
                }

                // Personel sayfasi
                if (workbook.SheetNames.includes('Personel')) {
                    const sheet = workbook.Sheets['Personel'];
                    const json = XLSX.utils.sheet_to_json(sheet);
                    const personnel = json.map((row, i) => ({
                        id: Date.now() + i,
                        name: row['Ad Soyad'] || '',
                        position: row['Pozisyon'] || '',
                        phone: row['Telefon'] || '',
                        plate: row['Plaka'] || '',
                        type: row['Tür'] || 'Şirket'
                    }));
                    const existing = DB.get('personnel') || [];
                    DB.set('personnel', [...existing, ...personnel]);
                }

                // Duyurular sayfasi
                if (workbook.SheetNames.includes('Duyurular')) {
                    const sheet = workbook.Sheets['Duyurular'];
                    const json = XLSX.utils.sheet_to_json(sheet);
                    const announcements = json.map(row => ({
                        id: generateId(),
                        title: row['Başlık'] || '',
                        content: row['İçerik'] || '',
                        type: row['Tür'] || 'Kayan',
                        startDate: row['Başlangıç'] || '',
                        endDate: row['Bitiş'] || '',
                        page: row['Sayfa'] || 'all'
                    }));
                    const existing = DB.get('announcements') || [];
                    DB.set('announcements', [...existing, ...announcements]);
                }

                showToast('Excel dosyası başarıyla içe aktarıldı!');
                updateDashboard();
                updatePersonnelDropdowns();
                renderAnnouncements();

            } catch (err) {
                console.error(err);
                showToast('Excel dosyası okunamadı!', 'error');
            }
        };
        reader.readAsArrayBuffer(file);
        e.target.value = '';
    });

    // Bireysel iceaktarma
    document.getElementById('importVisitorsBtn').addEventListener('click', () => {
        document.getElementById('importVisitorsFile').click();
    });

    document.getElementById('importVisitorsFile').addEventListener('change', (e) => {
        importSingleFile(e, 'visitors');
    });

    document.getElementById('importPersonnelBtn').addEventListener('click', () => {
        document.getElementById('importPersonnelFile').click();
    });

    document.getElementById('importPersonnelFile').addEventListener('change', (e) => {
        importSingleFile(e, 'personnel');
    });
}

function importSingleFile(e, type) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const data = new Uint8Array(event.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const json = XLSX.utils.sheet_to_json(sheet);

            if (type === 'visitors') {
                const visitors = json.map(row => ({
                    id: generateId(),
                    date: row['Tarih'] || '',
                    entryTime: row['Giriş Saati'] || row['Saat'] || '',
                    exitTime: row['Çıkış Saati'] || '',
                    name: row['Ad Soyad'] || '',
                    company: row['Firma'] || '',
                    plate: row['Plaka'] || '',
                    reason: row['Geliş Nedeni'] || '',
                    registeredBy: row['Kayıt Yapan'] || '',
                    status: row['Durum'] || 'Çıkış Yaptı'
                }));
                const existing = DB.get('visitors') || [];
                DB.set('visitors', [...existing, ...visitors]);
                showToast(`${visitors.length} ziyaretçi kaydı içe aktarıldı!`);
            } else if (type === 'personnel') {
                const personnel = json.map((row, i) => ({
                    id: Date.now() + i,
                    name: row['Ad Soyad'] || '',
                    position: row['Pozisyon'] || '',
                    phone: row['Telefon'] || '',
                    plate: row['Plaka'] || '',
                    type: row['Tür'] || 'Şirket'
                }));
                const existing = DB.get('personnel') || [];
                DB.set('personnel', [...existing, ...personnel]);
                showToast(`${personnel.length} personel kaydı içe aktarıldı!`);
                updatePersonnelDropdowns();
            }

            updateDashboard();

        } catch (err) {
            console.error(err);
            showToast('Dosya okunamadı!', 'error');
        }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = '';
}

// ===================== AYARLAR =====================
function initSettings() {
    const defaultRegisteredBy = document.getElementById('defaultRegisteredBy');
    const clearAllBtn = document.getElementById('clearAllData');

    defaultRegisteredBy.addEventListener('change', () => {
        const settings = DB.get('settings');
        settings.defaultRegisteredBy = defaultRegisteredBy.value;
        DB.set('settings', settings);
        showToast('Varsayılan kayıt yapan güncellendi');
    });

    clearAllBtn.addEventListener('click', () => {
        if (!confirm('TÜM VERİLER SİLİNECEK! Bu işlem geri alınamaz. Devam etmek istiyor musunuz?')) return;
        if (!confirm('Emin misiniz? Tüm ziyaretçi, personel ve duyuru kayıtları silinecek!')) return;

        localStorage.clear();
        DB.init();
        updateDashboard();
        updatePersonnelDropdowns();
        renderAnnouncements();
        showToast('Tüm veriler silindi!', 'warning');
    });

    // Varsayilan ayarlari yukle
    const settings = DB.get('settings');
    if (settings.defaultRegisteredBy) {
        defaultRegisteredBy.value = settings.defaultRegisteredBy;
    }
}

// ===================== UYGULAMA BASLAT =====================
document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initTheme();
    initDateTime();
    updatePersonnelDropdowns();
    updateDashboard();
    updateMarquee();
    initVisitorForm();
    initVisitorFilters();
    initPersonnelForm();
    initAnnouncementForm();
    initQuickExitModal();
    initExcelExport();
    initExcelImport();
    initSettings();
    renderPersonnelTable();
    renderAnnouncements();
});
